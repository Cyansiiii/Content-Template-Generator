import React, { useState } from 'react';
import { Wand2 } from 'lucide-react';
import { motion } from 'framer-motion';
import { ContentForm } from './components/Form/ContentForm';
import { ContentPreview } from './components/Preview/ContentPreview';
import { ContentFormData, GeneratedContent } from './types';
import { generateContent } from './utils/contentGenerator';

function App() {
  const [generatedContent, setGeneratedContent] = useState<GeneratedContent | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [progress, setProgress] = useState(0);

  const simulateProgress = () => {
    setProgress(0);
    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          return 100;
        }
        return prev + 10;
      });
    }, 200);
    return interval;
  };

  const handleSubmit = async (formData: ContentFormData) => {
    setIsGenerating(true);
    const progressInterval = simulateProgress();

    // Simulate generation time
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    const content = generateContent(formData.topic, formData.type, formData.tone);
    setGeneratedContent({
      type: formData.type,
      generatedContent: content,
    });

    clearInterval(progressInterval);
    setProgress(100);
    setTimeout(() => {
      setIsGenerating(false);
      setProgress(0);
    }, 500);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-purple-50 to-pink-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <motion.div 
          className="text-center mb-12"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <motion.div 
            className="flex items-center justify-center mb-4"
            whileHover={{ scale: 1.1 }}
            transition={{ type: "spring", stiffness: 300 }}
          >
            <Wand2 className="h-12 w-12 text-indigo-600" />
          </motion.div>
          <h1 className="text-5xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-indigo-600 to-purple-600 mb-4">
            Content Template Generator
          </h1>
          <p className="text-lg text-indigo-600 opacity-75">
            Transform your ideas into engaging content with the power of AI
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <motion.div 
            className="bg-white rounded-xl shadow-xl p-8 backdrop-blur-lg bg-opacity-90"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            <h2 className="text-2xl font-semibold mb-6 text-indigo-800">Create Content</h2>
            <ContentForm onSubmit={handleSubmit} isGenerating={isGenerating} />
          </motion.div>

          <motion.div 
            className="bg-white rounded-xl shadow-xl p-8 backdrop-blur-lg bg-opacity-90"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            <h2 className="text-2xl font-semibold mb-6 text-indigo-800">Preview</h2>
            <ContentPreview 
              content={generatedContent} 
              progress={progress}
              isGenerating={isGenerating}
            />
          </motion.div>
        </div>
      </div>
    </div>
  );
}

export default App;