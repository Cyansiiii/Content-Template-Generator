export interface ContentFormData {
  topic: string;
  type: ContentType;
  tone: ToneType;
}

export type ContentType = 'blog' | 'social' | 'article' | 'email' | 'presentation' | 'product-description' | 'press-release';
export type ToneType = 'professional' | 'casual' | 'friendly' | 'formal' | 'humorous' | 'inspirational' | 'technical' | 'persuasive';

export interface ContentFormProps {
  onSubmit: (data: ContentFormData) => void;
  isGenerating: boolean;
}

export interface GeneratedContent {
  type: string;
  generatedContent: string;
}

export interface PreviewProps {
  content: GeneratedContent | null;
  progress: number;
  isGenerating: boolean;
}

export interface ProgressBarProps {
  progress: number;
  isGenerating: boolean;
}