import React from 'react';
import { motion } from 'framer-motion';
import { ProgressBarProps } from '../../types';

export function ProgressBar({ progress, isGenerating }: ProgressBarProps) {
  if (!isGenerating) return null;

  return (
    <div className="w-full h-2 bg-gray-200 rounded-full overflow-hidden">
      <motion.div
        className="h-full bg-gradient-to-r from-indigo-500 to-purple-500"
        initial={{ width: 0 }}
        animate={{ width: `${progress}%` }}
        transition={{ duration: 0.5 }}
      />
    </div>
  );
}