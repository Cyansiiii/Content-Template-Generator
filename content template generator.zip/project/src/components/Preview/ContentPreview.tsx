import React from 'react';
import { motion } from 'framer-motion';
import { PreviewProps } from '../../types';
import { ProgressBar } from '../Progress/ProgressBar';

export function ContentPreview({ content, progress, isGenerating }: PreviewProps) {
  return (
    <div className="space-y-4">
      <ProgressBar progress={progress} isGenerating={isGenerating} />
      
      {!content && !isGenerating && (
        <motion.div 
          className="flex items-center justify-center h-64 bg-gradient-to-br from-indigo-50 to-purple-50 rounded-lg"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5 }}
        >
          <p className="text-indigo-400 italic text-center px-4">
            ✨ Your magical content will appear here ✨<br/>
            <span className="text-sm text-indigo-300">Fill out the form to generate amazing content</span>
          </p>
        </motion.div>
      )}

      {(content || isGenerating) && (
        <motion.div 
          className="prose max-w-none"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <div className="bg-white rounded-lg shadow-lg p-6 overflow-auto max-h-[600px]">
            <motion.div 
              className="mb-4"
              initial={{ scale: 0.9 }}
              animate={{ scale: 1 }}
              transition={{ duration: 0.3 }}
            >
              <span className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-gradient-to-r from-indigo-100 to-purple-100 text-indigo-800">
                {content?.type || 'Generating...'}
              </span>
            </motion.div>
            <motion.div 
              className="space-y-4 whitespace-pre-wrap"
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ duration: 0.5, delay: 0.2 }}
            >
              {content?.generatedContent || 'Generating your content...'}
            </motion.div>
          </div>
        </motion.div>
      )}
    </div>
  );
}