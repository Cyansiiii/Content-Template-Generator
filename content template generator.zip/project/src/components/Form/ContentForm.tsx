import React, { useState } from 'react';
import { Wand2, Loader2 } from 'lucide-react';
import { motion } from 'framer-motion';
import { ContentFormProps, ContentType, ToneType } from '../../types';

const contentTypes: { value: ContentType; label: string }[] = [
  { value: 'blog', label: 'Blog Post' },
  { value: 'article', label: 'Article' },
  { value: 'social', label: 'Social Media' },
  { value: 'email', label: 'Email Template' },
  { value: 'presentation', label: 'Presentation' },
  { value: 'product-description', label: 'Product Description' },
  { value: 'press-release', label: 'Press Release' },
];

const toneTypes: { value: ToneType; label: string }[] = [
  { value: 'professional', label: 'Professional' },
  { value: 'casual', label: 'Casual' },
  { value: 'friendly', label: 'Friendly' },
  { value: 'formal', label: 'Formal' },
  { value: 'humorous', label: 'Humorous' },
  { value: 'inspirational', label: 'Inspirational' },
  { value: 'technical', label: 'Technical' },
  { value: 'persuasive', label: 'Persuasive' },
];

export function ContentForm({ onSubmit, isGenerating }: ContentFormProps) {
  const [formData, setFormData] = useState({
    topic: '',
    type: 'blog' as ContentType,
    tone: 'professional' as ToneType,
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(formData);
  };

  return (
    <motion.form 
      onSubmit={handleSubmit} 
      className="space-y-6"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <motion.div
        whileHover={{ scale: 1.02 }}
        transition={{ type: "spring", stiffness: 300 }}
      >
        <label htmlFor="topic" className="block text-sm font-medium text-indigo-700">
          Topic
        </label>
        <input
          type="text"
          id="topic"
          value={formData.topic}
          onChange={(e) => setFormData({ ...formData, topic: e.target.value })}
          className="mt-1 block w-full rounded-lg border-2 border-indigo-100 shadow-sm focus:border-indigo-500 focus:ring focus:ring-indigo-200 focus:ring-opacity-50 p-3 transition-all duration-200"
          placeholder="Enter your topic"
          required
          disabled={isGenerating}
        />
      </motion.div>

      <motion.div
        whileHover={{ scale: 1.02 }}
        transition={{ type: "spring", stiffness: 300 }}
      >
        <label htmlFor="type" className="block text-sm font-medium text-indigo-700">
          Content Type
        </label>
        <select
          id="type"
          value={formData.type}
          onChange={(e) => setFormData({ ...formData, type: e.target.value as ContentType })}
          className="mt-1 block w-full rounded-lg border-2 border-indigo-100 shadow-sm focus:border-indigo-500 focus:ring focus:ring-indigo-200 focus:ring-opacity-50 p-3 transition-all duration-200"
          disabled={isGenerating}
        >
          {contentTypes.map((type) => (
            <option key={type.value} value={type.value}>
              {type.label}
            </option>
          ))}
        </select>
      </motion.div>

      <motion.div
        whileHover={{ scale: 1.02 }}
        transition={{ type: "spring", stiffness: 300 }}
      >
        <label htmlFor="tone" className="block text-sm font-medium text-indigo-700">
          Tone
        </label>
        <select
          id="tone"
          value={formData.tone}
          onChange={(e) => setFormData({ ...formData, tone: e.target.value as ToneType })}
          className="mt-1 block w-full rounded-lg border-2 border-indigo-100 shadow-sm focus:border-indigo-500 focus:ring focus:ring-indigo-200 focus:ring-opacity-50 p-3 transition-all duration-200"
          disabled={isGenerating}
        >
          {toneTypes.map((tone) => (
            <option key={tone.value} value={tone.value}>
              {tone.label}
            </option>
          ))}
        </select>
      </motion.div>

      <motion.button
        type="submit"
        disabled={isGenerating}
        className="w-full inline-flex items-center justify-center px-6 py-3 border border-transparent text-base font-medium rounded-lg shadow-sm text-white bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
        whileHover={{ scale: isGenerating ? 1 : 1.02 }}
        whileTap={{ scale: isGenerating ? 1 : 0.98 }}
      >
        {isGenerating ? (
          <>
            Generating
            <Loader2 className="ml-2 h-5 w-5 animate-spin" />
          </>
        ) : (
          <>
            Generate
            <Wand2 className="ml-2 h-5 w-5" />
          </>
        )}
      </motion.button>
    </motion.form>
  );
}